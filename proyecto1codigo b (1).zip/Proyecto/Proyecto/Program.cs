﻿
using System;
Console.WriteLine("Hecho por: Mauro Isaac Avila Vindas - 1247826");
Console.WriteLine("Hecho por: Wilder Alejandro Cardona Amézquita - 1220926");
Console.WriteLine("Sistema de Car Wash");


string nombreOperador = "";
string placa = "";
string nombreCliente = "";
int tipoVehiculo = 0;
Console.Write("Ingrese el nombre del operador: ");
nombreOperador = Console.ReadLine();
Console.WriteLine("Bienvenido, " + nombreOperador + "!");
double tarifaBase = 0.0;
double costoRines = 0.0;
int tamañoRin = 0;
string cancelarServicioRines = "";
    
bool ticketActivo = false;
bool servicioRinesActivo = false;

int totalCarrosAtendidos = 0;
int totalConServicioExtra = 0;
double totalIngresosSession = 0.0;


int opcionMenu;

do
    {
        Console.WriteLine("\n Menú \n 1. Crear ticket de entrada \n 2. Lavado de llantas y rines\n 3. Consultar monto a cobrar \n 4. Registrar salida y calcular cobro \n 5. Salir del programa");
        Console.Write("Ingrese su opción: ");
        opcionMenu = int.Parse(Console.ReadLine());

        switch (opcionMenu)
        {
            case 1:
                if (ticketActivo)
                {
                    Console.WriteLine("Ya existe un ticket activo. Por favor, registre la salida antes de crear uno nuevo.");
                    break;
                }
                Console.Write("Ingrese la placa del vehículo (6 caracteres): ");
                placa = Console.ReadLine().Trim();
                while (placa.Length != 6 || placa.Contains(" "))
                {
                    Console.WriteLine("Placa inválida. Debe tener exactamente 6 caracteres sin espacios.");
                    Console.Write("Ingrese la placa del vehículo (6 caracteres): ");
                placa = Console.ReadLine();
            }
               
                Console.WriteLine("Seleccione el tipo de vehículo: \n 1. Sedán (Q.50) \n 2. Pick-up o SUV (Q.75)");
                tipoVehiculo = int.Parse(Console.ReadLine());
                if (tipoVehiculo == 1)
                {
                    Console.WriteLine("La tarifa es de: Q.50");
                tarifaBase = 50.0;
                }
                else if (tipoVehiculo == 2)
                {
                Console.WriteLine("La tarifa es de: Q.75");
                tarifaBase = 75.0;
                }
                else
                {
                    Console.WriteLine("Tipo de vehículo inválido.");
                    break;
                }
                Console.WriteLine("Ingrese nombre del cliente");
                nombreCliente = Console.ReadLine();
                Console.WriteLine("Ticket creado exitosamente para " + nombreCliente + " con placa " + placa);

                ticketActivo = true;
 

                break;
            case 2:
                {
                    if (ticketActivo == false)
                    {
                        Console.WriteLine("Ya existe un ticket activo. Por favor, registre la salida antes de crear uno nuevo.");
                        break;
                    }
                    else
                    {
                        if (servicioRinesActivo)
                        {
                            Console.WriteLine($"El servicio esta activo {costoRines}, {tamañoRin}");
                            Console.WriteLine("Desea cancelar el servicio de lavado de rines? (S/N)");
                            cancelarServicioRines = Console.ReadLine();
                            if (cancelarServicioRines == "S" || cancelarServicioRines == "s")
                            {
                                costoRines = 0.0;
                                servicioRinesActivo = false;
                                Console.WriteLine("Servicio de lavado de rines cancelado exitosamente.");
                            }
                            else
                            {
                                Console.WriteLine("El servicio de lavado de rines sigue activo.");
                            }
                        }
                        else
                        {
                            Console.Write("Ingresar tamaño de los rines (12 a 22): ");
                            tamañoRin = int.Parse(Console.ReadLine());
                            // tamaño de rines valido
                            while (tamañoRin < 12 || tamañoRin > 22)
                            {
                                Console.WriteLine("Ingrese un tamaño de rines correcto (12 a 22).");
                                Console.Write("Tamaño de rines: ");
                                tamañoRin = int.Parse(Console.ReadLine());
                            }
                            // costo del servicio dependiendo del tamaño de los rines
                            if (tamañoRin >= 12 && tamañoRin <= 16)
                            {
                                costoRines = 30.0;
                            }
                            else if (tamañoRin >= 17 && tamañoRin <= 19)
                            {
                                costoRines = 40.0;
                            }
                            else
                            {
                                costoRines = 60.0;
                            }

                            servicioRinesActivo = true;
                            Console.WriteLine("Servicio extra agregado: Rines " + tamañoRin + " = Q" + costoRines);
                            Console.WriteLine("Total a cobrar: Q" + (tarifaBase + costoRines));
                        }
                    }
                } break;
            case 3:
                if (ticketActivo == false)
                {
                    Console.WriteLine("No hay ticket activo. Por favor, cree un ticket de entrada primero.");
                    break;
                }
                else
                {
                    double totalACobrar = tarifaBase + costoRines;
                    Console.WriteLine("Detalle del cobro para " + nombreCliente + ":");
                    Console.WriteLine("Monto a cobrar para " + nombreCliente);
                    Console.WriteLine("Base: Q" + tarifaBase);
                    if (servicioRinesActivo)
                    {
                        Console.WriteLine("Servicio de lavado de rines: Q" + costoRines);
                    }
                    Console.WriteLine("Total a cobrar: Q" + totalACobrar);
                    break;
                }
            case 4:
                if (ticketActivo == false)
                {
                    Console.WriteLine("No hay ticket activo. Por favor, cree un ticket de entrada primero.");
                    break;
                }
                else
                {
                    double totalACobrar = tarifaBase + costoRines;
                    Console.WriteLine("Salida registrada para " + nombreCliente + " con placa " + placa);
                    Console.WriteLine("Monto a cobrar: Q" + totalACobrar);
                    // Actualizar estadísticas
                    totalCarrosAtendidos++;
                    if (servicioRinesActivo)
                    {
                        totalConServicioExtra++;
                    }
                    totalIngresosSession += totalACobrar;
                    // Reiniciar variables para el próximo cliente
                    ticketActivo = false;
                    servicioRinesActivo = false;
                    tarifaBase = 0.0;
                    costoRines = 0.0;
                    placa = "";
                    nombreCliente = "";
                    tipoVehiculo = 0;
                
                Random random = new Random();   
                Console.Write("Elija un número del 1 al 3 para ganar una rifa: ");
                int NumeroC = int.Parse(Console.ReadLine());
                int numeroRandom = random.Next(1, 4);
                random = new Random();
                Console.WriteLine($"Número Car Wash: {numeroRandom}");

                if (NumeroC == numeroRandom)
                {
                    Console.WriteLine("¡Felicidades, ganó un viaje en yate todo pagado!");
                }
                else
                {
                    Console.WriteLine("Lástima, suerte a la próxima.");
                }
            }
                break;
            case 5:
              
                Console.WriteLine("Resumen de la sesión:");
                Console.WriteLine("Total de carros atendidos: " + totalCarrosAtendidos);
                Console.WriteLine("Total con servicio extra de lavado de rines: " + totalConServicioExtra);
            Console.WriteLine("Total de ingresos en la sesión: Q" + totalIngresosSession);
            Console.WriteLine("Saliendo del programa. ¡Gracias por usar el sistema de Car Wash!");
            break;
            default:
                Console.WriteLine("Opción inválida. Por favor, ingrese una opción del 1 al 5.");
                break;
        }
}
while (opcionMenu != 5);
